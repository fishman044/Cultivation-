(() => {
  const REALMS = [
    "Body Tempering","Qi Gathering","Qi Condensation","Foundation Establishment",
    "Spirit Sea","Golden Core","Nascent Soul","Soul Transformation",
    "Spirit Severing","Void Refinement","Dao Seeking","Mahayana",
    "Half-Immortal","True Immortal","Earth Immortal","Heaven Immortal",
    "Golden Immortal","Taiyi Immortal","Daluo Immortal","Immortal King",
    "Immortal Emperor","Dao Sovereign","Primordial Saint","Transcendent Ancestor"
  ];
  const STAGES = ["Early","Middle","Late"];
  const SAVE_KEY = "path24heavens_v1";

  const MANUALS = [
    {id:"breath",name:"Nine-Breath Circulation",grade:"Mortal",desc:"A stable beginner method.",cult:2,power:0,price:40,unlock:0},
    {id:"iron",name:"Iron-Sinew Scripture",grade:"Earth",desc:"Tempers flesh and bone.",cult:4,power:5,price:120,unlock:2},
    {id:"river",name:"Endless River Sutra",grade:"Heaven",desc:"Qi flows without interruption.",cult:9,power:10,price:420,unlock:5},
    {id:"star",name:"Star-Seizing Canon",grade:"Spirit",desc:"Draws spiritual power from the heavens.",cult:18,power:24,price:1200,unlock:8},
    {id:"void",name:"Void-Walking Record",grade:"Immortal",desc:"Refines space into the meridians.",cult:34,power:50,price:3600,unlock:12},
    {id:"dao",name:"Scripture of Ten Thousand Daos",grade:"Dao",desc:"A supreme method that harmonizes laws.",cult:70,power:110,price:10000,unlock:18}
  ];

  const PILLS = {
    qi:{name:"Qi Gathering Pill",desc:"Gain 80 cultivation Qi.",heal:0,qi:80},
    heal:{name:"Blood-Recovery Pill",desc:"Restore health during battle.",heal:45,qi:0},
    foundation:{name:"Foundation Pill",desc:"Adds +20% breakthrough chance once.",heal:0,qi:0},
    insight:{name:"Insight Pill",desc:"Permanently grants +1 Insight.",heal:0,qi:0}
  };

  const ARTIFACTS = [
    {id:"woodSword",name:"Spiritwood Sword",slot:"weapon",grade:"Mortal",power:6,price:90,unlock:0},
    {id:"jadeRobe",name:"Jade-Thread Robe",slot:"armor",grade:"Earth",power:13,price:260,unlock:3},
    {id:"cloudBoots",name:"Cloudstep Boots",slot:"boots",grade:"Heaven",power:22,price:650,unlock:6},
    {id:"soulBell",name:"Soul-Guarding Bell",slot:"treasure",grade:"Spirit",power:38,price:1500,unlock:9},
    {id:"voidBlade",name:"Void-Cleaving Blade",slot:"weapon",grade:"Immortal",power:75,price:4800,unlock:13},
    {id:"daoSeal",name:"Heavenly Dao Seal",slot:"treasure",grade:"Dao",power:150,price:14000,unlock:19}
  ];

  const RECIPES = {
    alchemy:[
      {id:"qi",name:"Qi Gathering Pill",cost:{herbs:2,stones:5},makes:["pills","qi"],amount:1},
      {id:"heal",name:"Blood-Recovery Pill",cost:{herbs:3,stones:8},makes:["pills","heal"],amount:1},
      {id:"foundation",name:"Foundation Pill",cost:{herbs:5,cores:1,stones:25},makes:["pills","foundation"],amount:1},
      {id:"insight",name:"Insight Pill",cost:{herbs:8,cores:2,stones:80},makes:["pills","insight"],amount:1}
    ],
    forge:[
      {id:"ironblade",name:"Refined Iron Blade",cost:{ore:5,stones:20},artifact:{id:"ironblade",name:"Refined Iron Blade",slot:"weapon",grade:"Earth",power:11}},
      {id:"coreguard",name:"Beast-Core Guard",cost:{ore:7,cores:2,stones:60},artifact:{id:"coreguard",name:"Beast-Core Guard",slot:"armor",grade:"Heaven",power:24}},
      {id:"spiritfan",name:"Spiritwind Fan",cost:{ore:10,cores:4,stones:160},artifact:{id:"spiritfan",name:"Spiritwind Fan",slot:"treasure",grade:"Spirit",power:42}}
    ]
  };

  const BASE_QUESTS = [
    {id:"cultivate5",name:"Steady Circulation",desc:"Cultivate 5 times.",metric:"cultivations",target:5,reward:{stones:50,herbs:2}},
    {id:"win2",name:"Blood on the Path",desc:"Win 2 battles.",metric:"wins",target:2,reward:{stones:70,ore:2}},
    {id:"craft2",name:"Hands of a Disciple",desc:"Craft 2 items.",metric:"crafted",target:2,reward:{stones:60,herbs:2,ore:2}},
    {id:"break1",name:"Defy the Bottleneck",desc:"Complete 1 breakthrough.",metric:"breakthroughs",target:1,reward:{stones:100,cores:1}}
  ];

  const freshState = () => ({
    version:1,
    name:"Wandering Cultivator",
    custom:{body:"slender",hair:"long",hairColor:"#151515",eyeColor:"#d2a846",skinTone:"#e0b394",robeColor:"#3c2d25",weapon:"sword",dao:"balanced"},
    realm:0,stage:0,qi:0,stones:100,herbs:6,ore:4,cores:0,
    stats:{strength:10,vitality:10,spirit:10,insight:5},
    hp:100,
    manualsOwned:["breath"],manualEquipped:"breath",
    pills:{qi:1,heal:2,foundation:0,insight:0},
    artifactsOwned:["woodSword"],equipped:{weapon:"woodSword",armor:null,boots:null,treasure:null},
    customArtifacts:[],
    metrics:{cultivations:0,wins:0,crafted:0,breakthroughs:0,explores:0},
    quests:BASE_QUESTS.map(q=>({...q,claimed:false})),
    log:[],
    eventLog:[],
    lastSaved:Date.now()
  });

  let state = loadState();
  let activeInv = "manuals";
  let activeCraft = "alchemy";
  let battle = null;

  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  function clamp(n,a,b){return Math.max(a,Math.min(b,n))}
  function fmt(n){return Math.floor(n).toLocaleString()}

  function saveState(show=true){
    state.lastSaved=Date.now();
    localStorage.setItem(SAVE_KEY, JSON.stringify(state));
    if(show) toast("Game saved");
  }
  function loadState(){
    try{
      const raw=localStorage.getItem(SAVE_KEY);
      if(!raw) return freshState();
      const parsed=JSON.parse(raw);
      const base=freshState();
      return {...base,...parsed,custom:{...base.custom,...parsed.custom},stats:{...base.stats,...parsed.stats},
        pills:{...base.pills,...parsed.pills},equipped:{...base.equipped,...parsed.equipped},
        metrics:{...base.metrics,...parsed.metrics}};
    }catch(e){return freshState()}
  }

  function realmIndex(){return state.realm*3+state.stage}
  function qiNeeded(){return Math.floor(100*Math.pow(1.22,realmIndex()))}
  function equippedManual(){return MANUALS.find(m=>m.id===state.manualEquipped)||MANUALS[0]}
  function manualBonus(){return equippedManual().cult}
  function artifactPower(){
    const all=[...ARTIFACTS,...state.customArtifacts];
    return Object.values(state.equipped).reduce((sum,id)=>sum+(all.find(a=>a.id===id)?.power||0),0)
  }
  function pathBonus(){
    return {balanced:0,sword:8,body:4,alchemy:0,formation:5}[state.custom.dao]||0
  }
  function power(){
    const idx=realmIndex();
    return Math.floor((state.stats.strength*2+state.stats.spirit*1.5+state.stats.vitality)+idx*18+artifactPower()+equippedManual().power+pathBonus())
  }
  function maxHp(){return Math.floor(100+state.stats.vitality*7+realmIndex()*22)}
  function cultivationGain(){
    const dao=state.custom.dao==="balanced"?2:state.custom.dao==="alchemy"?1:0;
    return Math.floor(8 + state.stats.spirit*.5 + manualBonus()+dao+state.realm*1.2)
  }
  function breakthroughChance(){
    const base=80 - state.realm*1.4 - state.stage*3 + state.stats.insight*1.2;
    return clamp(Math.floor(base),35,95)
  }
  function stageName(){return `${REALMS[state.realm]} · ${STAGES[state.stage]}`}

  function applyRealmStatGain(){
    state.stats.strength += 2 + Math.floor(state.realm/3);
    state.stats.vitality += 2 + Math.floor(state.realm/4);
    state.stats.spirit += 2 + Math.floor(state.realm/3);
    if(state.stage===0) state.stats.insight += 1;
    state.hp=maxHp();
  }

  function cultivate(){
    const gain=cultivationGain();
    state.qi=Math.min(qiNeeded(),state.qi+gain);
    state.metrics.cultivations++;
    toast(`+${gain} Qi`);
    update();
    saveState(false);
  }

  function breakthrough(){
    const need=qiNeeded();
    if(state.qi<need){toast("Fill your Qi first");return}
    if(state.realm===23&&state.stage===2){toast("You already stand beyond the Twenty-Four Heavens.");return}
    let chance=breakthroughChance();
    if(state.pills.foundation>0){chance+=20;state.pills.foundation--;toast("Foundation Pill consumed")}
    chance=clamp(chance,5,100);
    const roll=Math.random()*100;
    if(roll<=chance){
      state.qi=0;
      if(state.stage<2) state.stage++; else {state.stage=0;state.realm++}
      state.metrics.breakthroughs++;
      applyRealmStatGain();
      state.stones+=30+state.realm*15;
      addLog(`Breakthrough success → ${stageName()}!`);
      toast(`Breakthrough! ${stageName()}`);
    } else {
      state.qi=Math.floor(need*.72);
      addLog(`Breakthrough failed at ${stageName()}. Your foundation held, but qi scattered.`);
      toast(`Breakthrough failed (${chance}% chance)`);
    }
    update();saveState(false);
  }

  function getEnemies(){
    const idx=realmIndex();
    const templates=[
      ["Feral Spirit Wolf",0.72,18],["Rogue Cultivator",0.92,28],["Ironhide Ape",1.08,40],
      ["Sect Enforcer",1.18,52],["Ancient Ruin Guardian",1.35,80]
    ];
    return templates.map((t,i)=>{
      const ep=Math.floor(Math.max(12,power()*t[1]+idx*4));
      return {id:i,name:t[0],power:ep,hp:Math.floor(80+ep*3.6),reward:Math.floor(t[2]+idx*9+i*10),
        herbs:i===0?2:0,ore:i===2?2:0,cores:i>=2?1+(i===4?1:0):0,boss:i===4};
    });
  }

  function startBattle(enemy){
    const pHp=maxHp();
    battle={enemy:{...enemy,currentHp:enemy.hp},playerHp:Math.min(state.hp||pHp,pHp),playerMax:pHp,turn:0};
    $("#battleTitle").textContent=enemy.boss?`Boss: ${enemy.name}`:`Battle: ${enemy.name}`;
    $("#playerCombatName").textContent=state.name;
    $("#enemyCombatName").textContent=enemy.name;
    $("#liveCombatLog").innerHTML=`You face <b>${enemy.name}</b>.`;
    refreshBattle();
    $("#battleDialog").showModal();
  }

  function refreshBattle(){
    if(!battle)return;
    $("#playerHpBar").style.width=`${clamp(battle.playerHp/battle.playerMax*100,0,100)}%`;
    $("#enemyHpBar").style.width=`${clamp(battle.enemy.currentHp/battle.enemy.hp*100,0,100)}%`;
    $("#playerHpText").textContent=`${Math.max(0,Math.floor(battle.playerHp))} / ${battle.playerMax}`;
    $("#enemyHpText").textContent=`${Math.max(0,Math.floor(battle.enemy.currentHp))} / ${battle.enemy.hp}`;
  }
  function combatLine(s){$("#liveCombatLog").innerHTML += `<div>${s}</div>`;$("#liveCombatLog").scrollTop=$("#liveCombatLog").scrollHeight}
  function playerAttack(tech=false){
    if(!battle)return;
    const base=power();
    const variance=.85+Math.random()*.3;
    let dmg=Math.floor(base*(tech?1.45:1)*variance/5+8);
    if(tech){
      const qiCost=Math.max(5,Math.floor(qiNeeded()*.025));
      if(state.qi<qiCost){toast("Not enough Qi for a technique");return}
      state.qi-=qiCost;
    }
    battle.enemy.currentHp-=dmg;
    combatLine(`${tech?"✨ Technique":"⚔️ Attack"} deals <b>${dmg}</b> damage.`);
    if(battle.enemy.currentHp<=0){winBattle();return}
    enemyTurn();
  }
  function enemyTurn(){
    if(!battle)return;
    const e=battle.enemy;
    const mitigation=state.stats.vitality*.25+artifactPower()*.08;
    const dmg=Math.max(3,Math.floor((e.power/7)*(0.8+Math.random()*.35)-mitigation*.08));
    battle.playerHp-=dmg;
    combatLine(`${e.name} strikes for <b>${dmg}</b>.`);
    if(battle.playerHp<=0){
      state.hp=Math.floor(maxHp()*.35);
      state.qi=Math.floor(state.qi*.9);
      addLog(`Defeated by ${e.name}. You escaped with your cultivation intact.`);
      combatLine(`<b>You were defeated.</b> Ten percent of stored Qi scattered.`);
      setTimeout(()=>{$("#battleDialog").close();battle=null;update()},500);
    }
    refreshBattle();saveState(false);
  }
  function winBattle(){
    const e=battle.enemy;
    state.stones+=e.reward;state.herbs+=e.herbs;state.ore+=e.ore;state.cores+=e.cores;
    state.metrics.wins++;state.hp=Math.max(1,Math.floor(battle.playerHp));
    const qiGain=Math.floor(cultivationGain()*1.8);
    state.qi=Math.min(qiNeeded(),state.qi+qiGain);
    combatLine(`<b>Victory!</b> +${e.reward} stones, +${qiGain} Qi${e.cores?`, +${e.cores} core(s)`:""}.`);
    addLog(`Defeated ${e.name}.`);
    setTimeout(()=>{$("#battleDialog").close();battle=null;update();saveState(false)},700);
  }
  function combatHeal(){
    if(!battle)return;
    if(state.pills.heal<=0){toast("No Blood-Recovery Pills");return}
    state.pills.heal--;
    const amount=Math.floor(battle.playerMax*.35)+PILLS.heal.heal;
    battle.playerHp=Math.min(battle.playerMax,battle.playerHp+amount);
    combatLine(`💊 Restored <b>${amount}</b> health.`);
    refreshBattle();enemyTurn();
  }
  function flee(){
    if(!battle)return;
    const success=Math.random()<.7;
    if(success){combatLine("You escape safely.");setTimeout(()=>{$("#battleDialog").close();battle=null;update()},250)}
    else{combatLine("Escape failed!");enemyTurn()}
  }

  function usePill(id){
    if((state.pills[id]||0)<=0){toast("None available");return}
    if(id==="foundation"){toast("Foundation Pills are consumed automatically on your next breakthrough.");return}
    state.pills[id]--;
    if(id==="qi"){state.qi=Math.min(qiNeeded(),state.qi+PILLS.qi.qi);toast("+80 Qi")}
    if(id==="heal"){state.hp=Math.min(maxHp(),(state.hp||maxHp())+Math.floor(maxHp()*.45));toast("Health restored")}
    if(id==="insight"){state.stats.insight++;toast("+1 permanent Insight")}
    update();saveState(false);
  }

  function canAfford(cost){return Object.entries(cost).every(([k,v])=>(state[k]||0)>=v)}
  function spend(cost){Object.entries(cost).forEach(([k,v])=>state[k]-=v)}
  function craft(recipe){
    if(!canAfford(recipe.cost)){toast("Missing crafting materials");return}
    spend(recipe.cost);
    if(recipe.makes){
      const [bag,id]=recipe.makes;state[bag][id]=(state[bag][id]||0)+(recipe.amount||1);
    }else if(recipe.artifact){
      const unique={...recipe.artifact,id:`${recipe.artifact.id}_${Date.now()}`};
      state.customArtifacts.push(unique);state.artifactsOwned.push(unique.id);
    }
    state.metrics.crafted++;
    toast(`Crafted ${recipe.name}`);update();saveState(false);
  }

  function explore(){
    const roll=Math.random();
    state.metrics.explores++;
    if(roll<.35){const n=2+Math.floor(Math.random()*4);state.herbs+=n;worldEvent(`You found a hidden herb patch. +${n} herbs.`)}
    else if(roll<.65){const n=2+Math.floor(Math.random()*4);state.ore+=n;worldEvent(`You discovered a mineral vein. +${n} ore.`)}
    else if(roll<.85){const n=25+state.realm*15;state.stones+=n;worldEvent(`You uncovered an old cultivator's cache. +${n} spirit stones.`)}
    else {state.cores++;worldEvent("A wounded spirit beast fell nearby. +1 beast core.")}
    update();saveState(false)
  }
  function meditate(){
    const gain=cultivationGain()*3;
    state.qi=Math.min(qiNeeded(),state.qi+gain);state.hp=maxHp();state.metrics.cultivations+=3;
    worldEvent(`Closed-door meditation stabilized your foundation. +${gain} Qi and full health.`);
    update();saveState(false)
  }

  function claimQuest(q){
    const progress=state.metrics[q.metric]||0;
    if(progress<q.target||q.claimed)return;
    Object.entries(q.reward).forEach(([k,v])=>state[k]=(state[k]||0)+v);
    q.claimed=true;toast("Quest reward claimed");update();saveState(false);
  }

  function buyManual(id){
    const m=MANUALS.find(x=>x.id===id);if(!m)return;
    if(state.realm<m.unlock){toast(`Requires ${REALMS[m.unlock]}`);return}
    if(state.stones<m.price){toast("Not enough spirit stones");return}
    state.stones-=m.price;state.manualsOwned.push(id);state.manualEquipped=id;toast(`${m.name} learned and equipped`);update();saveState(false);
  }
  function equipManual(id){state.manualEquipped=id;toast("Manual equipped");update();saveState(false)}
  function buyArtifact(id){
    const a=ARTIFACTS.find(x=>x.id===id);if(!a)return;
    if(state.realm<a.unlock){toast(`Requires ${REALMS[a.unlock]}`);return}
    if(state.stones<a.price){toast("Not enough spirit stones");return}
    state.stones-=a.price;state.artifactsOwned.push(id);state.equipped[a.slot]=id;toast(`${a.name} acquired and equipped`);update();saveState(false)
  }
  function equipArtifact(id){
    const all=[...ARTIFACTS,...state.customArtifacts];const a=all.find(x=>x.id===id);if(!a)return;
    state.equipped[a.slot]=id;toast(`${a.name} equipped`);update();saveState(false)
  }

  function addLog(line){state.log.unshift(line);state.log=state.log.slice(0,25)}
  function worldEvent(line){state.eventLog.unshift(line);state.eventLog=state.eventLog.slice(0,12);toast(line)}

  function updateAvatar(){
    const a=$("#avatar"),c=state.custom;
    a.style.setProperty("--hair",c.hairColor);a.style.setProperty("--eyes",c.eyeColor);
    a.style.setProperty("--skin",c.skinTone);a.style.setProperty("--robe",c.robeColor);
    a.dataset.hair=c.hair;a.dataset.body=c.body;a.dataset.weapon=c.weapon;
  }

  function updateHeader(){
    $("#heroName").textContent=state.name;$("#realmLabel").textContent=stageName();
    $("#qiBar").style.width=`${Math.min(100,state.qi/qiNeeded()*100)}%`;
    $("#qiText").textContent=`${fmt(state.qi)} / ${fmt(qiNeeded())} Qi`;
    $("#powerText").textContent=`Power ${fmt(power())}`;
    $("#stones").textContent=fmt(state.stones);$("#herbs").textContent=fmt(state.herbs);
    $("#ore").textContent=fmt(state.ore);$("#cores").textContent=fmt(state.cores);
    $("#cultivationRate").textContent=`+${cultivationGain()} Qi / cycle`;
    $("#breakthroughBtn").disabled=state.qi<qiNeeded()||(state.realm===23&&state.stage===2);
    updateAvatar();
  }

  function renderStats(){
    const stats=[["STR",state.stats.strength],["VIT",state.stats.vitality],["SPI",state.stats.spirit],["INS",state.stats.insight]];
    $("#statGrid").innerHTML=stats.map(x=>`<div class="stat"><b>${x[1]}</b><small>${x[0]}</small></div>`).join("");
  }

  function renderRealmPath(){
    $("#realmPath").innerHTML=REALMS.map((r,i)=>{
      const done=i<state.realm, current=i===state.realm;
      const status=done?"Cleared":current?`${STAGES[state.stage]} · ${Math.floor(state.qi/qiNeeded()*100)}%`:"Locked";
      return `<div class="realm-row ${done?"done":""} ${current?"current":""}">
        <div class="realm-num">${i+1}</div><div><b>${r}</b><small>Early → Middle → Late</small></div><div class="realm-status">${status}</div>
      </div>`;
    }).join("");
  }

  function renderEnemies(){
    $("#enemyList").innerHTML=getEnemies().map((e,i)=>`<div class="item-card">
      <h4>${e.boss?"👑 ":""}${e.name}</h4><p>${e.boss?"A dangerous realm boss.":"A roaming threat on your path."}</p>
      <div class="item-meta"><span class="tag">Power ${fmt(e.power)}</span><span>Reward ${fmt(e.reward)} 💠</span>${e.cores?`<span>${e.cores} 🔮</span>`:""}</div>
      <div class="item-actions"><button class="${e.power>power()*1.15?"danger":"secondary"}" data-enemy="${i}">Fight</button></div>
    </div>`).join("");
    $$("[data-enemy]").forEach(b=>b.onclick=()=>startBattle(getEnemies()[+b.dataset.enemy]));
    $("#battleLog").innerHTML=state.log.length?state.log.map(x=>`<div>• ${x}</div>`).join(""):"Your path is quiet… for now.";
  }

  function renderQuests(){
    $("#questList").innerHTML=state.quests.map((q,i)=>{
      const p=state.metrics[q.metric]||0, done=p>=q.target;
      const rewards=Object.entries(q.reward).map(([k,v])=>`${v} ${k}`).join(" · ");
      return `<div class="item-card"><h4>${q.claimed?"✅ ":done?"⭐ ":""}${q.name}</h4><p>${q.desc}</p>
      <div class="item-meta"><span>${Math.min(p,q.target)} / ${q.target}</span><span>${rewards}</span></div>
      <div class="item-actions"><button class="${done&&!q.claimed?"primary":"secondary"}" data-quest="${i}" ${!done||q.claimed?"disabled":""}>${q.claimed?"Claimed":"Claim"}</button></div></div>`;
    }).join("");
    $$("[data-quest]").forEach(b=>b.onclick=()=>claimQuest(state.quests[+b.dataset.quest]));
  }

  function renderInventory(){
    $("#inventoryTitle").textContent=activeInv[0].toUpperCase()+activeInv.slice(1);
    let html="";
    if(activeInv==="manuals"){
      html=MANUALS.map(m=>{
        const owned=state.manualsOwned.includes(m.id),eq=state.manualEquipped===m.id;
        return `<div class="item-card"><h4>${eq?"☯ ":""}${m.name}</h4><p>${m.desc}</p><div class="item-meta"><span class="tag">${m.grade}</span><span>+${m.cult} Qi/cycle</span><span>+${m.power} power</span></div>
        <div class="item-actions">${owned?`<button class="${eq?"primary":"secondary"}" data-equip-manual="${m.id}" ${eq?"disabled":""}>${eq?"Equipped":"Equip"}</button>`:`<button class="secondary" data-buy-manual="${m.id}">Buy · ${m.price} 💠</button>`}</div></div>`;
      }).join("");
      $("#inventoryCount").textContent=`${state.manualsOwned.length} learned`;
    } else if(activeInv==="pills"){
      html=Object.entries(PILLS).map(([id,p])=>`<div class="item-card"><h4>💊 ${p.name} × ${state.pills[id]||0}</h4><p>${p.desc}</p><div class="item-actions"><button class="secondary" data-use-pill="${id}" ${(state.pills[id]||0)<=0?"disabled":""}>Use</button></div></div>`).join("");
      $("#inventoryCount").textContent=`${Object.values(state.pills).reduce((a,b)=>a+b,0)} pills`;
    } else if(activeInv==="artifacts"){
      const all=[...ARTIFACTS,...state.customArtifacts];
      html=all.map(a=>{
        const owned=state.artifactsOwned.includes(a.id),eq=state.equipped[a.slot]===a.id;
        return `<div class="item-card"><h4>${eq?"✦ ":""}${a.name}</h4><p>${a.slot} artifact.</p><div class="item-meta"><span class="tag">${a.grade}</span><span>+${a.power} power</span></div>
        <div class="item-actions">${owned?`<button class="${eq?"primary":"secondary"}" data-equip-art="${a.id}" ${eq?"disabled":""}>${eq?"Equipped":"Equip"}</button>`:`<button class="secondary" data-buy-art="${a.id}">Buy · ${a.price} 💠</button>`}</div></div>`;
      }).join("");
      $("#inventoryCount").textContent=`${state.artifactsOwned.length} owned`;
    } else {
      html=`<div class="item-card"><h4>🌿 Spirit Herbs × ${state.herbs}</h4><p>Used in alchemy.</p></div>
      <div class="item-card"><h4>⛏️ Refined Ore × ${state.ore}</h4><p>Used to forge artifacts.</p></div>
      <div class="item-card"><h4>🔮 Beast Cores × ${state.cores}</h4><p>Rare cores used in advanced recipes.</p></div>
      <div class="item-card"><h4>💠 Spirit Stones × ${state.stones}</h4><p>Universal cultivation currency.</p></div>`;
      $("#inventoryCount").textContent="Crafting resources";
    }
    $("#inventoryList").innerHTML=html;
    $$("[data-equip-manual]").forEach(b=>b.onclick=()=>equipManual(b.dataset.equipManual));
    $$("[data-buy-manual]").forEach(b=>b.onclick=()=>buyManual(b.dataset.buyManual));
    $$("[data-use-pill]").forEach(b=>b.onclick=()=>usePill(b.dataset.usePill));
    $$("[data-equip-art]").forEach(b=>b.onclick=()=>equipArtifact(b.dataset.equipArt));
    $$("[data-buy-art]").forEach(b=>b.onclick=()=>buyArtifact(b.dataset.buyArt));
  }

  function costText(cost){return Object.entries(cost).map(([k,v])=>`${v} ${k}`).join(" · ")}
  function renderCraft(){
    $("#craftTitle").textContent=activeCraft==="alchemy"?"Alchemy":"Artifact Forge";
    $("#recipeList").innerHTML=RECIPES[activeCraft].map((r,i)=>`<div class="item-card"><h4>${activeCraft==="alchemy"?"💊":"⚒️"} ${r.name}</h4>
      <p>${activeCraft==="alchemy"?"Refine spiritual ingredients into a consumable pill.":"Forge a permanent equippable artifact."}</p>
      <div class="item-meta"><span>${costText(r.cost)}</span></div><div class="item-actions"><button class="${canAfford(r.cost)?"primary":"secondary"}" data-recipe="${i}" ${canAfford(r.cost)?"":"disabled"}>Craft</button></div></div>`).join("");
    $$("[data-recipe]").forEach(b=>b.onclick=()=>craft(RECIPES[activeCraft][+b.dataset.recipe]));
  }

  function renderWorld(){
    const ranks=[
      [3,"Outer Sect Disciple","Sect commissions and guarded cultivation grounds are now open to you."],
      [6,"Inner Sect Disciple","You have become a recognized expert of your generation."],
      [10,"Core Elder","Your word carries weight across mortal cultivation regions."],
      [13,"Ascended Immortal","Mortal sect politics now seem very small."],
      [17,"Immortal Sect Ancestor","Great lineages seek your favor."],
      [20,"Heavenly Overlord","Entire immortal domains acknowledge your authority."],
      [23,"Transcendent Ancestor","You stand at the threshold beyond the known Dao."]
    ];
    let chosen=["Unaffiliated Wanderer","Reach Foundation Establishment to join a sect and unlock higher-grade commissions."];
    ranks.forEach(([r,n,d])=>{if(state.realm>=r)chosen=[n,d]});
    $("#sectRank").textContent=chosen[0];$("#sectDesc").textContent=chosen[1];
    $("#worldEvents").innerHTML=state.eventLog.length?state.eventLog.map(x=>`<div>• ${x}</div>`).join(""):"Rumors drift on the wind.";
  }

  function update(){
    updateHeader();renderStats();renderRealmPath();renderEnemies();renderQuests();renderInventory();renderCraft();renderWorld();
  }

  function toast(msg){
    const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast._t);toast._t=setTimeout(()=>t.classList.remove("show"),1800)
  }

  function openCharacter(){
    $("#charName").value=state.name;$("#bodyType").value=state.custom.body;$("#hairStyle").value=state.custom.hair;
    $("#hairColor").value=state.custom.hairColor;$("#eyeColor").value=state.custom.eyeColor;$("#skinTone").value=state.custom.skinTone;
    $("#robeColor").value=state.custom.robeColor;$("#weaponStyle").value=state.custom.weapon;$("#daoPath").value=state.custom.dao;
    $("#characterDialog").showModal();
  }
  function applyCharacter(e){
    e.preventDefault();
    state.name=$("#charName").value.trim()||"Wandering Cultivator";
    state.custom={body:$("#bodyType").value,hair:$("#hairStyle").value,hairColor:$("#hairColor").value,
      eyeColor:$("#eyeColor").value,skinTone:$("#skinTone").value,robeColor:$("#robeColor").value,
      weapon:$("#weaponStyle").value,dao:$("#daoPath").value};
    $("#characterDialog").close();update();saveState(false);toast("Character updated");
  }

  $$(".bottom-nav button").forEach(b=>b.onclick=()=>{
    $$(".bottom-nav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");
    $$(".view").forEach(v=>v.classList.remove("active"));$(`#view-${b.dataset.view}`).classList.add("active");
  });
  $$("[data-inv]").forEach(b=>b.onclick=()=>{$$("[data-inv]").forEach(x=>x.classList.remove("active"));b.classList.add("active");activeInv=b.dataset.inv;renderInventory()});
  $$("[data-craft]").forEach(b=>b.onclick=()=>{$$("[data-craft]").forEach(x=>x.classList.remove("active"));b.classList.add("active");activeCraft=b.dataset.craft;renderCraft()});

  $("#cultivateBtn").onclick=cultivate;$("#breakthroughBtn").onclick=breakthrough;$("#saveBtn").onclick=()=>saveState(true);
  $("#editCharacterBtn").onclick=openCharacter;$("#applyCharacterBtn").onclick=applyCharacter;
  $("#attackBtn").onclick=()=>playerAttack(false);$("#techniqueBtn").onclick=()=>playerAttack(true);$("#combatPillBtn").onclick=combatHeal;$("#fleeBtn").onclick=flee;
  $("#battleCloseBtn").onclick=()=>{if(battle){state.hp=Math.max(1,Math.floor(battle.playerHp));battle=null}$("#battleDialog").close();update()};
  $("#clearLogBtn").onclick=()=>{state.log=[];renderEnemies();saveState(false)};
  $("#exploreBtn").onclick=explore;$("#meditateBtn").onclick=meditate;

  // Passive recovery and autosave.
  setInterval(()=>{state.hp=Math.min(maxHp(),(state.hp||maxHp())+1)},5000);
  setInterval(()=>saveState(false),20000);
  document.addEventListener("visibilitychange",()=>{if(document.hidden)saveState(false)});

  if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./service-worker.js").catch(()=>{});
  update();
})();