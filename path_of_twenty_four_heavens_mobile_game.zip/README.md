# Path of Twenty-Four Heavens

A mobile-first cultivation RPG prototype.

## Included systems
- 24 major cultivation realms, each with Early / Middle / Late stages (72 advancement steps)
- Manual learning and equipping
- Pills and consumable effects
- Artifact buying, equipping, and forging
- Turn-based fights with attacks, techniques, healing, bosses, victory rewards, and defeat penalties
- Quests with tracked objectives and claimable rewards
- Alchemy and artifact crafting
- Character customization: name, body silhouette, hair, colors, robe, weapon, and Dao path
- Sect/world progression
- Local save data and autosave
- PWA manifest + service worker for installable/offline behavior when hosted over HTTPS

## Play locally
Open `index.html` in a modern browser. Core gameplay and saving work locally.

## Install like a mobile app
For PWA installation/offline caching, host this folder on an HTTPS site (for example GitHub Pages, Cloudflare Pages, Netlify, or similar) and open it in a supporting mobile browser.

## Reset save
In browser/site settings, clear storage for the game origin.

## Notes
The prototype uses no external libraries, images, tracking, ads, or network calls.
